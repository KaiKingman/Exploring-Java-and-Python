import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

public class WriteObjects {
	public static void main(String[] args) {
		String fileName = "test.bin";
		
		System.out.println("Writing objects...");
		
		Person[] people = {new Person(1, "Sue"), new Person(99, "Mike"), new Person(7, "Bob")};
		
		ArrayList<Person> peopleList = new ArrayList<Person>(Arrays.asList(people));
		
		
		try(FileOutputStream fs = new FileOutputStream(fileName)) {	// will write to working dir, which is the java proj
			// no need to close "fs" since we're using newer than Java 6
			ObjectOutputStream os = new ObjectOutputStream(fs);
			
			os.writeObject(people);
			
			os.writeObject(peopleList);
			
			os.writeInt(peopleList.size());
			
			for(Person person: peopleList) {
				os.writeObject(person);
			}
			
			os.close();	// not gonna lie, kinda ugly since inconsistent with not closing "fs"
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found: "+fileName);
		} catch (IOException e) {
			System.out.println("IOException caught.");
		}
	}
}