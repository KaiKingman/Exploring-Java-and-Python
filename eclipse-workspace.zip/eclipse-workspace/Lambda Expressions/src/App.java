interface Executable {
	int execute(int a, int b);
}

class Runner {
	public void run(Executable e) {
		
		System.out.println("Executing code block...");
		int value = e.execute(12, 13);
		System.out.println("Return value is: " + value);
	}
}

public class App {
	public static void main(String[] args) {
		
		int c = 100;
		
		int d = 77;
		
		Runner runner = new Runner();
		
		
		runner.run(new Executable() {	// no-name newly created Executable obj is an anon. class
			public int execute(int a, int b) {
				System.out.println("Hello there.");
				return c + a + b;
			}
		});
		
		System.out.println("===========================");
		
		runner.run(	(int a, int b) -> {
			System.out.println("This is code passed in a lambda expression.");
			return a + b;
		});
		
		Executable ex = (int a, int b) -> {
			System.out.println("OTHER code in a lambda expression.");
			return a + b;
		};
		
		runner.run(ex);
		
		Object codeblock = (Executable)(a,b) -> {
			System.out.println("Hello there");
			return a+b+c;
		};
		
		/*
		 * 	() represents the execute() method
		 * 	-> represents the pointer to the line(s) of code the execute() method has
		 * 	lines of code inside the curly braces are the actual lines executed by execute()
		 * 
		 * 	1st EXAMPLE lambda expression: 
		 * 
		 * 	() -> {
				System.out.println("This is code passed in a lambda expression.");
			}
			
			2nd EXAMPLE lambda expression:
			
			() -> {
				System.out.println("This is code passed in a lambda expression.");
				return 8;
			}
			
			3rd EXAMPLE lambda expression:
			
			(int a) -> {
				System.out.println("This is code passed in a lambda expression.");
				return 8 + a;
			}
			
			4th EXAMPLE lambda expression:
			
			(int a, int b) -> {
				System.out.println("This is code passed in a lambda expression.");
				return a + b;
			}
		 */
	}
}
