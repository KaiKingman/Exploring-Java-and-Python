import java.util.ArrayList;
import java.util.HashMap;

public class App {

	public static void main(String[] args) {
		ArrayList<String> strings = new ArrayList<String>();
		
		strings.add("cat");
		strings.add("dog");
		strings.add("alligator");
		
		String animal = strings.get(1);
		System.out.println(animal);
		
		// Can have more than one type of argument
		HashMap<Integer, String> map = new HashMap<Integer, String>();
	}

}