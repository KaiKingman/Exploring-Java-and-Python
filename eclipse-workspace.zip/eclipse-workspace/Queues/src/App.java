import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;

public class App {

	public static void main(String[] args) {
		//	(head)<- oooooooooooooooooooooooo <- (tail)
		
		// ArrayBlockingQueues have a defined finite range
		Queue<Integer> q1 = new ArrayBlockingQueue<Integer>(3);
		
		try { 
			System.out.println("Head of queue is: " + q1.element());
		} catch (NoSuchElementException e) {
			System.out.println("Tried to get head of empty queue");
		}
		
		q1.add(10);
		q1.add(20);
		q1.add(30);
		
		System.out.println("\nHead of queue is: " + q1.element());
		
		try {
			q1.add(40);
		} catch (IllegalStateException e) {
			System.out.println("\nTried to add too many items to the queue\n");
		}
		
		for(Integer value: q1) {
			System.out.println("Queue value: " + value);
		}
		
		System.out.println("\nremoved from queue: " + q1.remove());
		System.out.println("removed from queue: " + q1.remove());
		System.out.println("removed from queue: " + q1.remove());
		
		try {
			System.out.println("removed from queue: " + q1.remove());
		} catch(NoSuchElementException e) {
			System.out.println("Tried to remove too many items from queue\n");
		}
		
		/////////////////////////////////////////////////////////////////////////
		
		Queue<Integer> q2 = new ArrayBlockingQueue<Integer>(2);
		
		System.out.println("Queue 2 peek: " + q2.peek());
		
		q2.offer(10);		// offer() to attempt to add to queue
		q2.offer(20);
		if(q2.offer(30) == false) {
			System.out.println("\nOffer failed to add third item.\n");
		}
		
		for(Integer value: q2) {
			System.out.println("Queue 2 value: " + value);
		}
		
		System.out.println("\nQueue 2 poll: " + q2.poll());		// poll() to attempt to remove from queue
		System.out.println("Queue 2 poll: " + q2.poll());
		System.out.println("Queue 2 poll: " + q2.poll());
	}

}
