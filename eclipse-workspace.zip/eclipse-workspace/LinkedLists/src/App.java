import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class App {

	public static void main(String[] args) {
		/*
		 * ArrayLists manage arrays internally.
		 * 
		 * [0][1][2][3][4][5] ....
		 * 		
		 * stacked next to each other, meaning getting a specific item is fast
		 * 
		 * very fast to add to end of list, since a new array is made by moving items to 
		 * a larger, newly copied list to store the new item
		 * 
		 * very slow to add something to middle of list, all elements after target location
		 * need to be moved to make space for the entry
		 */
		List<Integer> arrayList = new ArrayList<Integer>();		// use arrayLists for adding/removing items at end or start of list
		
		/*
		 * LinkedLists are made up of pieces that all have references to the element before
		 * and after themselves
		 * 
		 * [0]->[1]->[2] ...
		 *    <-   <-
		 * 
		 * very slow to get to specific point in LinkedList, since a chain of references need to be made
		 * 
		 * very fast to add items to middle of list, since the references of the elements surrounding
		 * the new item just change their references to reference the new item instead
		 * 		example: inserting [9] after [0] but before [1] in the list above means that [0]
		 * 		references [9] instead of [1], and [1] references [9] instead of [0]
		 */
		LinkedList<Integer> linkedList = new LinkedList<Integer>();		// use linkedLists for adding/removing items anywhere in list
		
		doTimings("Array", arrayList);
		doTimings("LinkedList", linkedList);
	}
	
	private static void doTimings(String type, List<Integer> list) {
		for(int i=0; i<1E5; i++) {
			list.add(i);
		}
		
		long start = System.currentTimeMillis();
		
		/*
		// Add items at end of list
		for (int i=0; i<1E5; i++) {
			list.add(i);
		}
		*/
		
		// Add items elsewhere in list0
		for (int i=0; i<1E5; i++) {
			list.add(list.size(), i);
		}
		
		long end = System.currentTimeMillis();
		
		System.out.println("Time taken: " + (end - start) + " ms for " + type);
	}

}