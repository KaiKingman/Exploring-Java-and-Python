class Frog {
	private int id;
	private String name;
	
	
	public Frog(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	// Having no toString() method returns the name of the parent class + the @hashcode
	public String toString() {
		
		// return "string" + "string2"	is bad because concatenating strings creates new strings, being inefficient
		
		//return String.format("%-3d: %s", id, name);		// to return by using the string format method
		
		///*
		StringBuilder sb = new StringBuilder();
		sb.append(id).append(": ").append(name);
		return sb.toString();
		//*/
	}
}

public class UsingEfficientReturningOfToStringConstructors {
	public static void main(String[] args) {
		Frog frog1 = new Frog(7, "Bob");
		Frog frog2 = new Frog(2, "Freddy");
		
		System.out.println(frog1);
		System.out.println(frog2);
	}

}
