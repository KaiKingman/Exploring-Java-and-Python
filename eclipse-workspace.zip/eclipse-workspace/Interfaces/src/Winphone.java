
public class Winphone implements Info {
	
	private String name;	
	
	public Winphone(String name) {		
		this.name = name;
	}

	public void greet() {
		System.out.println("Hello there, I'm a crappy Windows phone.");
	}

	@Override
	public void showInfo() {
		System.out.println("WinPhone name is: "+name);
	}
}
