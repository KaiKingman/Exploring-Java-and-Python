
public class Iphone implements Info {
	
	private int id = 7;
	
	public void start() {
		System.out.println("Iphone started.");
	}

	@Override
	public void showInfo() {
		System.out.println("Iphone ID is: "+id);
	}
}
