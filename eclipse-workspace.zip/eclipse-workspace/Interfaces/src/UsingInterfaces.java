public class UsingInterfaces {

	public static void main(String[] args) {
		Iphone iphone1 = new Iphone();
		iphone1.start();
		
		Winphone winphone1 = new Winphone("WinPhone1.0");
		winphone1.greet();
		
		Info info1 = new Iphone();	// info1 of interface Info can only use stuff in Info, not Iphone but is still an Iphone
		info1.showInfo();
		
		Info info2 = winphone1;
		info2.showInfo();
		
		outputInfo(iphone1);
		outputInfo(winphone1);
	}
	
	private static void outputInfo(Info info) {
		info.showInfo();
	}

}