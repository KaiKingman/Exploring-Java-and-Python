class Thing {
	public String name;
	public static String description;
	
	// final means can't change value
	public final static int LUCKY_NUMBER = 42;
	
	public static int count = 0;		// static means shared between all objects	
	
	public int id;		// not static, so value is not the same for all objects of class Thing
	
	public Thing() {
		id = count;
		count++;
	}
	
	public void showName() {
		System.out.println(name);
	}
	
	public static void showInfo() {
		System.out.println(description); 	// static methods can only have static variables
	}
}

public class UsingStaticAndFinalModifiers {
	public static void main(String[] args) {
		
		Thing.description = "I am a thing";
		
		Thing.showInfo();
		
		Thing thing1 = new Thing();		// increments count by one by instantiating a thing1, object of Thing
		System.out.println("Thing1's ID is "+thing1.id);
		
		Thing thing2 = new Thing();		// increments count by one by instantiating a thing2, object of Thing
		System.out.println("Thing2's ID is "+thing2.id);
		
		//Thing.LUCKY_NUMBER = 2;		// not allowed, because LUCKY_NUMBER of class Thing is final
		
		System.out.println(Thing.LUCKY_NUMBER);
		
		System.out.println("Before creating objects, count is: "+Thing.count);
	}

}