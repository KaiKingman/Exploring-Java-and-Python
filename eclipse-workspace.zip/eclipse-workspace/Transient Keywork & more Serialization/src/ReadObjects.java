import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ReadObjects {	

	public static void main(String[] args) {
		
		System.out.println("Reading objects...");
		
		try (ObjectInputStream os = new ObjectInputStream(new FileInputStream("test.ser"))) {		
			
			Person person1 = (Person) os.readObject();	// "readObject()" func could be reading obj of non-existent class
				// deserialization, where object fields are read and recreated
			
			os.close();
			
			System.out.println(person1);
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found: "+"test.ser");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found: Person");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("\nFinished reading objects.");
	}
}
