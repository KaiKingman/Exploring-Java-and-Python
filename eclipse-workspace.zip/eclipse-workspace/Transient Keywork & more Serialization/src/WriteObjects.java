import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class WriteObjects {
	public static void main(String[] args) {
		
		System.out.println("Writing objects...");			
		
		// no need to close "fs" since we're using newer than Java 6 
		
		try(ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("test.ser"))) {	// will write to working dir, which is the java proj					
			
			Person mike = new Person(543, "Mike");
			Person.setCount(88);
			os.writeObject(mike);	// object "mike" of class "person" serialized into outputStream
			
			os.close();	// not gonna lie, kinda ugly since inconsistent with not closing "fs"
			
		} catch (FileNotFoundException e) {
			System.out.println("File not found: "+"test.ser");
		} catch (IOException e) {
			System.out.println("IOException caught.");
		}
		
		System.out.println("\nFinished writing objects.");
	}
}