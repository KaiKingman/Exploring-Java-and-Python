import java.util.Scanner;

public class App {
	public static void main(String[] args) {			
		while(true) {
			Scanner inputScanner = new Scanner(System.in);
			int userInput = inputScanner.nextInt();
			System.out.println("Your time in minutes, "+userInput+", is "+convert(userInput)+" seconds.");
		}
	}
	public static long convert(int minutes) {		
		return minutes*60;
	}
}