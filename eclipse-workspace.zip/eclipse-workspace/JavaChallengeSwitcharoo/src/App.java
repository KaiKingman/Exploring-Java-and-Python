import java.util.Scanner;

public class App {
	public static void main(String[] args) {
		while(true) {
			Scanner inputScanner = new Scanner(System.in);
			System.out.print("Enter a string: ");
			
			StringBuilder userString = new StringBuilder(inputScanner.nextLine());
			
			if (userString.length() <= 2) {
				System.out.println("Incompatible.");
			} else if (userString.charAt(0) == userString.charAt(userString.length()-1)) {
				System.out.println("Two's a pair.");
			} else {	
				char userStringFirstChar = userString.charAt(0);	// remember first char
				
				userString.setCharAt(0, 		userString.charAt(userString.length()-1));	// change first char
				userString.setCharAt(userString.length()-1,		userStringFirstChar);	// change "last char" with "remembered first char"
				
				System.out.println(userString);
			}
		}
	}
}
