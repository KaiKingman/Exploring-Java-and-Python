
public class App {

	public static void main(String[] args) {
		
		byte byteValue = 125;
		short shortValue = 55;
		int intValue = 888;
		long longValue = 12032;
		float floatValue = 5.1333102983172983f;
		double doubleValue = 32.112;
		
		byteValue = (byte)129;
		System.out.println(byteValue);
	}

}
