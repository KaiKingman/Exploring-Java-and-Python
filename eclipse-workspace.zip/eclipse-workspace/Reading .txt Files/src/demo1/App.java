package demo1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class App {

	public static void main(String[] args) throws FileNotFoundException {
		//String fileName = "C:\\Users\\wanga\\Desktop\\Example.txt";
		String fileName = "Example.txt";	// if file path is not specified, file is found from root working directory of java proj
		
		File textFile = new File(fileName);
		
		Scanner in = new Scanner(textFile);
		
		int value = in.nextInt();			// wont read the "newline" character at end of line, just the next int
		System.out.println("Read value: "+value);
		
		in.nextLine();		
		// need this to move the scanner cursor to the second line by skipping the txt file's first line's "newline" character
		
		int count = 2;		// int to say that first line read from .txt file is the second line
		
		while (in.hasNextLine()) {
			if (count <= value+1) {
				String line = in.nextLine();
				System.out.println(count+": "+line);
				count++;
			}
		}
		
		in.close();
	}

}
