import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class App {

	public static void main(String[] args) {
		// HashSet is not organized in order
		Set<String> hashSet = new HashSet<String>();
		
		// LinkedHashSet keeps original order
		Set<String> linkedHashSet = new LinkedHashSet<String>();
		Set<String> linkedHashSet2 = new LinkedHashSet<String>();
		
		// TreeSet organizes by natural order
		Set<String> treeSet = new TreeSet<String>();
		
		addAndPrintSet1(linkedHashSet);
		addAndPrintSet2(linkedHashSet2, linkedHashSet);
	}
	
	public static Set<String> addAndPrintSet1(Set<String> set) {
		set.add("dog");
		set.add("cat");
		set.add("dinosaur");
		set.add("shark");
		set.add("bear");
		
		// check if set is empty
		if (set.isEmpty()) {
			System.out.println("Set is empty after attempting to add elements to set");
		}
		
		// Adding duplicate items does nothing
		set.add("dinosaur");
		
		System.out.println(set);
		
		// iterative set printout
		for(String element: set) {
			System.out.println(element);
		}
		
		// Does set contain a given item?
		if (set.contains("cat")) {
			System.out.println("Contains cat\n");
		}
		
		return set;
	}
	
	public static Set<String> addAndPrintSet2(Set<String> set, Set<String> otherSet) {
		set.add("dog");
		set.add("cat");
		set.add("giraffe");
		set.add("monkey");
		set.add("ant");
		
		//		intersection		//
		
		Set<String> intersection = new HashSet<String>(set);
		intersection.retainAll(otherSet);
		
		System.out.println("Intersection: " + intersection);
		
		//		differences			//
		
		Set<String> difference = new LinkedHashSet<String>(set);
		difference.removeAll(otherSet);
		
		System.out.println("Differences: " + difference);
		
		return set;
	}

}
