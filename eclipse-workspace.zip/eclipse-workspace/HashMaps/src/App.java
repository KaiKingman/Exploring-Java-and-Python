import java.util.HashMap;
import java.util.Map;

public class App {

	public static void main(String[] args) {
		/*
		 * stores pairs of values where one is the "key" and one is the "value"
		 * 
		 * use angle brackets to specify the "value type, key type"
		 * 
		 * use the put() method to retrieve a "value" by entering the "key" as 1st param
		 * 
		 * "null" is returned if a not-recognized key is retrieved
		 * 
		 * duplicate values are ok, but only the latest duplicate of a key is used
		 * 		example: 2 entries with identical keys overwrite the keys put into the map before them
		 */
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		
		map.put(5, "Five");
		map.put(6, "Six");
		map.put(9, "Nine");
		map.put(4, "Four");
		map.put(2, "Two");
		map.put(0, "Zero");
		
		map.put(6, "Hello");
		
		String text = map.get(6);
		
		System.out.println(text);
		
		for(Map.Entry<Integer, String> entry: map.entrySet()) {
			int key = entry.getKey();
			String value = entry.getValue();
			
			System.out.println(key + ": " + value);
		}
	}
}