
public class App {

	
	public static void main(String[] args) {
		// 4! = 4*3*2*1 (factorial of 4)
		System.out.println(factorial(5));
		
	}
	
	private static int factorial(int value) {		
		System.out.println(value);
		
		if (value == 1) {
			return 1;
		}
		return value * factorial(value-1);
	}
}
