
/*
 * 		ACCESS MODIFIER SUMMARY
 * private --- only within same class
 * public --- from anywhere
 * protected --- same class, or subclass, or package
 * no modifier --- only same package
 */


public class UsingAccessModifiers {

	public static void main(String[] args) {
		Plant plant1 = new Plant();
		
		System.out.println(plant1.name);
		System.out.println(plant1.ID);
	}

}
