
public class Oak extends Plant {
	public Oak() {
		this.size = "large";
	}
}
