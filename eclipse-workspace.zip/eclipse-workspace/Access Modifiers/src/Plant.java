
public class Plant {
	// Bad practice
	public String name;
	
	// Acceptable because it is final (not changeable)
	public final static int ID = 8; 
	
	private String type;
	
	protected String size;
	
	public Plant() {		
		this.name = "Freddy";
		this.type = "Plant";
		this.size = "Medium";
	}
}
