import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;

public class App {

	public static void main(String[] args) {
		Test test = new Test();
		
		/*
		try {
			test.run();
		} catch (IOException e) {
			// IOException specific stuff here			
		} catch (ParseException e) {
			// ParseException specific stuff here
			System.out.println("Couldn't parse command file.");
		}
		*/
		
		/*
		try {
			test.run();
		} catch (IOException | ParseException e) {
			// Generic stuff for both IOExceptions and ParseExceptions
			e.printStackTrace();
		}
		*/
		
		try {
			test.run();
		} catch (Exception e) {		// catches "all exceptions" of class "Exception"
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			test.input();
		} catch (FileNotFoundException e) {		// must be handled before parent class "IOException"
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}

}