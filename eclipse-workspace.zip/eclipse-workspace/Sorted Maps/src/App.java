import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class App {

	public static void main(String[] args) {
		/*
		 * HashMaps are called "HashMaps" because they store hashes, which are address codes to objs
		 * 
		 * SOMETIMES organizes entries in natural numerical order
		 */
		Map<Integer, String> hashMap = new HashMap<Integer, String>();		// using map makes it more generic, giving more access to map-specific methods
		
		/*
		 * like LinkedLists, where each entry has reference to entry before and after them
		 * 
		 * does not organize list, keeps everything in original order
		 */
		Map<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();
		
		// list that organizes entries in the natural order (1 2 3 4, alphabetical), but the order can be redefined
		Map<Integer, String> treeMap = new TreeMap<Integer, String>();
		
		testMap(treeMap);
		
	}
	
	public static void testMap(Map<Integer, String> map) {
		map.put(9, "fox");
		map.put(4, "cat");
		map.put(8, "crab");
		map.put(1, "donkey");
		map.put(7, "shrek");
		map.put(3, "deer");
		map.put(5, "johnny");
		map.put(0, "dick");
		
		for (Integer key: map.keySet()) {		// sets are thigns that for loops can iterate over
			String value = map.get(key);
			
			System.out.println(key + " : " + value);
		}
	}

}
