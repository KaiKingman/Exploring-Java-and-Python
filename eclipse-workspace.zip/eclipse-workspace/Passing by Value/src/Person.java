
public class Person {
	private String name;

	public Person(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {	// makes displaying an obj of class "Person" using a printed-out string possible 
		// TODO Auto-generated method stub
		return "Person [name=" + name + "]";
	}
}
