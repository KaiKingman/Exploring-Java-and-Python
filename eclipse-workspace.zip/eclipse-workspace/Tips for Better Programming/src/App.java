
public class App {
	public static void main(String[] args) {
		// type instead of just reading tutorials
		// read stack traces from the top to the line down
		// try to write the smallest working program possible
		// google like crazy
		// build and run programs after making even small changes
	}
}
