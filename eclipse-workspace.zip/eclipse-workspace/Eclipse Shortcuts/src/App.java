import java.util.ArrayList;

public class App {

	// create "main" method = type "main", then ctrl+space
	public static void main(String[] args) {
		// print noticeably-colored text = type "syserr", then ctrl+space
		System.err.println("Oh no something fucked up");
		
		// rename var = highlight var declaration, alt+shift+R, then type new name
		ArrayList newlyNamedArray;
		
		// find var declaration = press F3 while highlighting or cursor is on var
		newlyNamedArray = new ArrayList();
	}
	
	// format code = ctrl+shift+F
	
	// run normally (custom) = ctrl+R
	
	// run in debug mode = F11
	
	// add/organize imports = ctrl+shift+O
	
	// generate methods/constructors/etc through source = alt+shift+S
}
