
public class App {

	public static void main(String[] args) {
		
		Robot robot1 = new Robot(7);
		robot1.start();
		
		
		// Only possible if inner class "Brain" of class "Robot" is made public
		//Robot.Brain brain = robot1.new Brain();
		
		Robot.Battery battery = new Robot.Battery();
		battery.charge();
	}

}
