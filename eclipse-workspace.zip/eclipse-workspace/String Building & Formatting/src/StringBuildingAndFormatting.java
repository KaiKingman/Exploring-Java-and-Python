
public class StringBuildingAndFormatting {

	public static void main(String[] args) {
		
		String info = "";		// strings, once set, can never be changed
		// inefficient and slow
		info += "My name is Bob.";
		info += " ";
		info += "I am a builder.";
		
		System.out.println(info);
		
		
		StringBuilder sb = new StringBuilder("");	// stringbuilders can be changed AKA appended
		// efficient and much faster
		sb.append("\nMy name is Sue.");
		sb.append(" ");
		sb.append("I am a lion tamer.");
		
		System.out.println(sb);
		
		
		StringBuilder s = new StringBuilder();
		s.append("\nMy name is roger")
		.append(" ")
		.append("I am a skydiver");
		
		System.out.println(s);
		
		
		
		// Formatting
		System.out.print("\nHere is some text.\tThat was a tab.\nThat was a new line.");
		System.out.println(" This text is on the same line.\n");
		
		
		// printf is for special formatting characters
		System.out.printf("Total cost as an int is %d", 5);		// %d makes func look for corresponding int argument
		
		System.out.printf("\nTotal cost as two ints are %d and %d", 5, 20);
		
		
		for (int i = 0; i < 20; i++) {
			System.out.printf("%4d: some text here\n", i);	// %2d places it in certain place to vertically align all numbers
		}
		
		System.out.printf("Total value: %.2f\n", 5.6902982);	// %.2f makes float value round to nearest 2 decimal place
		
		// it is also possible to combine these, like %5.2 (2 decimal places, 5 spaces to the right alignment)
	}

}
