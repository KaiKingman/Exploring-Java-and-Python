
public interface SentientBeing {
	public void StateInfo(String name);	
}
