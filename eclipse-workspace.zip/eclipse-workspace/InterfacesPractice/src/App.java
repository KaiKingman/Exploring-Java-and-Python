
public class App {
	public static void main(String[] args) {
		SentientBeing Bob = new Human();
		Bob.StateInfo("Bob");
		
		SentientBeing CEPO = new Machine();
		CEPO.StateInfo("C3-P0");
	}

}