
public class Human implements SentientBeing {
	@Override
	public void StateInfo(String name) {
		System.out.println("My name is "+name+" and I am a human.");			
	}
}
