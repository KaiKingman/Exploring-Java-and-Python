import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class App {

	public static void main(String[] args) {
		//		LISTS		//
		
		/*
		 * STORE GENERIC LIST OF OBJS
		 * 
		 * duplicates are allowed
		 * 
		 * objs stay in original organization
		 * 
		 * index of each element is an integer
		 * 
		 * checking for a singular element is very slow
		 * 
		 * finding an element by index is very fast
		 * 
		 * iterating through lists is ok-fast
		 * 
		 * can be sorted
		 */
		
		//	use to add/remove items at end of list
		List<String> list1 = new ArrayList<String>();
		
		// use to remove/add items elsewhere in the list
		List<String> list2 = new LinkedList<String>();
		
		
		
		
		
		
		
		//		SETS		//
		
		/*
		 * USE TO STORE UNIQUE VALUES, NO DUPLICATES
		 * 
		 * there is no index for elements
		 * 
		 * checking if a certain obj exists is very fast
		 * 
		 * built to quickly find a certain obj and removing duplicates
		 * 
		 * must implement hashCode() and equals() if using custom objs
		 */
		
		// order is not ordered and is not important
		Set<String> set1 = new HashSet<String>();
		
		// sorted by natural order and must implement Comparable for custom orders
		Set<String> set2 = new TreeSet<String>();
		
		// original order remains in order they were inputted
		Set<String> set3 = new LinkedHashSet<String>();
		
		
		
		
		
		
		//		MAPS		//
		
		/*
		 * STORE PAIRS, EACH WITH A KEY AND VALUE
		 * 
		 * get values by using keys, which is very fast
		 * 
		 * map iteration is very slow
		 * 
		 * not optimized to be iterated through
		 * 
		 * must implement hashCode() and equals() if using your own objs
		 */
		
		// keys are not in a certain order, and the order can change
		Map<String, String> map1 = new HashMap<String, String>();
		
		// keys are sorted in natural order
		// must implement Comparable for custom orders
		Map<String, String> map2 = new TreeMap<String, String>();
		
		// keys stay in order they were inputted
		Map<String, String> map3 = new LinkedHashMap<String, String>();
		
		// SortedSet and SortedMap interfaces also exist
	}

}
