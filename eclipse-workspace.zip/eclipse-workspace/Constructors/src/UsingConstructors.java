class Machine {
	public String name;	
	public int code;
	public String mission;
	
	public Machine(String name) {		// first constructor
		this.name = name;
	}
	
	public Machine(String name, int code) {		// second constructor
		this(name);		// calls first constructor
		this.code = code;
	}
	
	public Machine(String name, int code, String mission) {		//third constructor
		this(name, code);
		this.mission = mission;
	}
}

public class UsingConstructors {
	public static void main(String[] args) {
		Machine machine1 = new Machine("Andrew");		
		System.out.println(machine1.name+" is his name\n");
		
		Machine machine2 = new Machine("Duby", 42);
		System.out.println(machine2.name+" is his name and his code is "+machine2.code+"\n");
		
		Machine machine3 = new Machine("Heistatron", 420, "heist the world");
		System.out.println(machine3.name+" is his name and his code is "+machine3.code+" and his mission is to "+machine3.mission);
	}
}