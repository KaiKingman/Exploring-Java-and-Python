
public class Car extends Macbook {
	
	
	@Override			// use this to REALLY make sure method is overriding parent method and not creating a new one
	public void start() {
		System.out.println("Car started");	
	}

	public void wipeWindShield() {
		System.out.println("Wiping windshield");
	}
	
	public void getAllName() {
		System.out.println("My allName is "+allName);
	}
}