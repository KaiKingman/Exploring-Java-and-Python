
public class Inheritance {

	public static void main(String[] args) {
		Macbook mac1 = new Macbook();
		mac1.start();
		mac1.stop();
		
		Car car1 = new Car();
		car1.start();
		car1.stop();
		car1.getAllName();
	}	

}
