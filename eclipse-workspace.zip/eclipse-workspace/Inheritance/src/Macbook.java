
public class Macbook {
	
	
	// private means only accessible inside class, NOT EVEN the child classes, meaning only Macbook class can access name
	private String name = "Macbook Type 1";
	
	
	// protected means only accessible by class AND ALSO child classes
	protected String allName = "allMacbook Type 1";
	
	public void start() {
		System.out.println("Macbook started.");
	}
	public void stop() {
		System.out.println("Macbook stopped");
	}
	public void getName() {
		System.out.println("My private name is "+name);
	}
}
