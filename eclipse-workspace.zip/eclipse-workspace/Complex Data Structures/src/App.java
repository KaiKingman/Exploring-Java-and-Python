import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class App {
	
	public static String[] vehicles = {
		"ambulance", "helicopter", "lifeboat"	
	};
	
	public static String[][] drivers = {
		{"Fred", "Sue", "Pete"}, 
		{"Sue", "Richard", "Bob", "Fred"}, 
		{"Pete", "Mary", "Bob"}	
	};
	
	public static void main(String[] args) {
		
		Map<String, Set<String>> personnel = new HashMap<String, Set<String>>();
		
		// for loop adds the list of drivers for each vehicle to the HashMap, 'personnel'
		for (int i=0; i<vehicles.length; i++) {
			String vehicle = vehicles[i];		// vehicle = each vehicle
			
			String[] driversList = drivers[i];	// vehicle's driver list = set of drivers
			
			Set<String> driverSet = new LinkedHashSet<String>();
			
			// add each driver in the current vehicle's driversList to
			// the placeholder driverSet to be sorted
			for(String driver: driversList) {
				driverSet.add(driver);
			}
			
			// add the specific vehicle and its 1x2 array of drivers for
			// the vehicle in the 'personnel' HashMap, which is not sorted
			personnel.put(vehicle, driverSet);
		}
		
		// Example usage to get make a sorted Set of helicopter drivers from
		// the 'personnel' set of the list of drivers for each vehicle
		Set<String> heliDriversList = personnel.get("helicopter");
		
		// iterate through the sub-set 'personnel' that contains the helicopter
		// drivers and printout each helicopter driver
		for(String heliDriver: heliDriversList) {
			System.out.println(heliDriver);
		}
		
		// iterate through the entire personnel set
		for(String vehicle: personnel.keySet()) {
			System.out.print("\n"+vehicle);
			System.out.print(": ");

			Set<String> driversList = personnel.get(vehicle);
			
			for (String driver: driversList) {
				System.out.print(driver);
				System.out.print(" ");
			}
		}
	}

}
