
public class App {

	public static void main(String[] args) {
		
		String[] texts = {"one", "two", "three"};		
		try {
			System.out.println(texts[3]);
		} catch (Exception e) {
			System.out.println("gotcha bitch");
		}
		
		
		String text = null;		// string value is not actually given, just set to null
		System.out.println(text.length());		// code "points" to the value of "text", which is "null"
		
		
		int value = 7;
		value /= 0;		// "runtime AKA unchecked exception" because compiler allows it but is caught during runtime
		
		
		try {
			Thread.sleep(1000);		// "checked exception" because compiler won't allow it before runtime
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
