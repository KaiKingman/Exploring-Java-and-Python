package snippet;

public class Snippet {
	Set<String> linkedHashSet = new LinkedHashSet<String>();
}

