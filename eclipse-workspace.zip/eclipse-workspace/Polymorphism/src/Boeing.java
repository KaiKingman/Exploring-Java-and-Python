
public class Boeing extends Airplane {
	@Override
	public void grow() {
		System.out.println("Boeing manufacturing");
	}
	
	public void produceBoeing() {
		System.out.println("Producing boeing plane");
	}
}
