
public class UsingPolymorphism {

	public static void main(String[] args) {
		Airplane airplane1 = new Airplane();		// new airplane object
		
		
		// can replace mention of a parent class with a child class
		
		Airplane airplane2 = airplane1;			// stored in same physical airplane object from line 5
			//will execute grow method from "Airplane" class
		
		//Airplane airplane2 = boeing;		// also works, because Boeing is child extension of Airplane
			//will execute grow method from "Boeing" class
		
		airplane2.grow();
		
		
		Boeing boeing = new Boeing();
		Airplane airplane3 = boeing;
		
		boeing.produceBoeing();		// will work because produceBoeing() method is defined in object class "Boeing"
		//airplane3.produceBoeing();	// wont work becuz even tho "airplane3" is stored in object "boeing", 
										// the "Airplane" object class has no defined method as "produceBoeing()
		
		airplane3.grow();			// will work because grow() func is defined in Airplane class
		
	}

}
