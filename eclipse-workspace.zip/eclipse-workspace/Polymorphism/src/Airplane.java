
public class Airplane {

	public void grow() {
		System.out.println("Airplane manufacturing");
	}

}
