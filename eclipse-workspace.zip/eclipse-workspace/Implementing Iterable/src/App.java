
public class App {

	public static void main(String[] args) {
		
		UrlLibrary urlLib = new UrlLibrary();
		
		// for-each loop with custom iterator "urlLib", 
		//	a "UrlLibrary" obj that implements "Iterable" interface
		for(String html: urlLib) {
			System.out.println(html.length());
			//System.out.println(html);
		}
	}

}
