
public class Camera extends Machine {

	@Override
	public void start() {
		System.out.println("Starting Camera.");
	}

	@Override
	public void doStuff() {
		System.out.println("Do stuff with camera.");
	}

	@Override
	public void shutdown() {
		System.out.println("Shut down camera.");
		
	}
	
}
